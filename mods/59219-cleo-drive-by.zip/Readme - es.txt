CLEO Drive By
------------------------------------------------------------------------------------------------
CLEO Unidad para GTA San Andreas. 

El script agrega la posibilidad de disparar desde el asiento del conductor como un coche, una moto o una Bicicleta, el uso de cualquier tipo de armas de fuego. Muy útil para diversas actividades, el despido de los vehículos. 

Para descargar esta modificación, siga los enlaces de abajo.

################################################################################################

AUTORES
------------------------------------------------------------------------------------------------
Autor principal Zacthe_nerd

################################################################################################

INSTRUCCIONES DE INSTALACIÓN
------------------------------------------------------------------------------------------------
1. La copia de archivos

(!) No se olvide de hacer copias de la original de los archivos reemplazados a ser capaz de eliminar la modificación!

Copie todo el contenido de la carpeta "00 - Copy to game folder" a la carpeta donde está instalado el juego. Confirmar el reemplazo.

################################################################################################

Esta modificación ha sido descargado de www.gtaall.net

Permanent enlace a modification`s página: https://www.gtaall.net/gta-san-andreas/cleo/59219-cleo-drive-by.html

Compruebe nuestra sociales groups!
http://vk.com/gtaallcom
https://twitter.com/gtaallnet
http://www.facebook.com/gtaallcom
http://www.youtube.com/gtaallcom