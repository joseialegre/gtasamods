CLEO Drive By
------------------------------------------------------------------------------------------------
CLEO Lecteur pour GTA San Andreas. 

Le script ajoute la possibilité de tirer à partir du siège du conducteur, comme une voiture, une moto ou un Vélo, d'utiliser tout type d'armes à feu. Très utile pour diverses activités, en tirant sur les véhicules. 

Pour télécharger cette modification, suivez les liens ci-dessous.

################################################################################################

AUTEURS
------------------------------------------------------------------------------------------------
L'auteur principal Zacthe_nerd

################################################################################################

INSTRUCTIONS D'INSTALLATION
------------------------------------------------------------------------------------------------
1. La copie des fichiers

(!) Ne pas oublier de faire des copies de l'original remplacés fichiers pour être en mesure de retirer la modification!

Copiez tout le contenu du dossier "00 - Copy to game folder" dans le dossier où le jeu est installé. Confirmer le remplacement.

################################################################################################

Cette modification a été téléchargé à partir de www.gtaall.eu

Permanent lien vers modification`s page: https://www.gtaall.eu/fr/gta-san-andreas/cleo/59219-cleo-drive-by.html

Vérifier notre sociale groups!
http://vk.com/gtaallcom
https://twitter.com/gtaallcom
http://www.facebook.com/gtaallcom
http://www.youtube.com/gtaallcom