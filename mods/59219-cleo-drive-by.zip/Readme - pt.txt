CLEO Drive By
------------------------------------------------------------------------------------------------
CLEO Unidade para o GTA San Andreas. 

O script adiciona a capacidade para filmar a partir do assento do motorista, como um carro, uma moto ou uma Bicicleta, usando qualquer tipo de armas de fogo. Muito útil para várias atividades, disparando sobre os veículos. 

Para baixar esta modificação, siga os links abaixo.

################################################################################################

AUTORES
------------------------------------------------------------------------------------------------
Autor principal Zacthe_nerd

################################################################################################

INSTRUÇÕES DE INSTALAÇÃO
------------------------------------------------------------------------------------------------
1. Cópia de arquivo

(!) Não se esqueça de fazer cópias do original arquivos substituídos para ser capaz de remover a modificação!

Copie todo o conteúdo da pasta "00 - Copy to game folder" para a pasta onde o jogo está instalado. Confirmar a substituição.

################################################################################################

Esta modificação foi baixado www.gtaall.com.br

Permanent link para modification`s página: https://www.gtaall.com.br/gta-san-andreas/cleo/59219-cleo-drive-by.html

Check a nossa sociais groups!
http://vk.com/gtaallcom
https://twitter.com/gtaallcombr
http://www.facebook.com/gtaallcom
http://www.youtube.com/gtaallcom