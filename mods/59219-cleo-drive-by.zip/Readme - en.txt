CLEO Drive By
------------------------------------------------------------------------------------------------
CLEO Drive By for GTA San Andreas. 

The script adds the ability to shoot from the driver's seat as a car, motorcycle or Bicycle, using any kind of firearms. Very useful for various pursuits, firing on vehicles. 

To download this modification, follow the links below.

################################################################################################

AUTHORS
------------------------------------------------------------------------------------------------
Main author Zacthe_nerd

################################################################################################

INSTALLATION INSTRUCTIONS
------------------------------------------------------------------------------------------------
1. File copying

(!) Do not forget to make copies of the original replaced files to be able to remove the modification!

Copy all the contents of the folder "00 - Copy to game folder" to the folder where the game is installed. Confirm the replacement.

################################################################################################

This modification has been downloaded from www.gtaall.com

Permanent link to modification`s page: https://www.gtaall.com/gta-san-andreas/cleo/59219-cleo-drive-by.html

Check out our social groups!
http://vk.com/gtaallcom
https://twitter.com/gtaallcom
http://www.facebook.com/gtaallcom
http://www.youtube.com/gtaallcom