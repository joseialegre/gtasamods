CLEO Drive By
------------------------------------------------------------------------------------------------
CLEO-Laufwerk, Indem Sie für GTA San Andreas. 

Das Skript fügt die Fähigkeit zu Schießen vom Fahrersitz aus wie ein Auto, Motorrad oder Fahrrad, mit jeder Art von Schusswaffen. Sehr nützlich für verschiedene Aktivitäten, feuern auf Fahrzeuge. 

Zum download dieser änderung, Folgen Sie den links unten.

################################################################################################

AUTOREN
------------------------------------------------------------------------------------------------
Hauptautor Zacthe_nerd

################################################################################################

EINBAUANLEITUNG
------------------------------------------------------------------------------------------------
1. Kopieren von Dateien

(!) Vergessen Sie nicht, machen Kopien des Originals ersetzt Dateien in der Lage sein, um die Änderung zu entfernen!

Kopieren Sie den gesamten Inhalt des Ordners "00 - Copy to game folder" auf den Ordner, in dem das Spiel installiert ist. Bestätigen Sie den Ersatz.

################################################################################################

Diese Modifikation wurde von www.gtaall.eu heruntergeladen wurden
Permanent Link zu Seite modification`s: https://www.gtaall.eu/de/gta-san-andreas/cleo/59219-cleo-drive-by.html

Überprüfen unsere sozialen groups!
http://vk.com/gtaallcom
https://twitter.com/gtaallcom
http://www.facebook.com/gtaallcom
http://www.youtube.com/gtaallcom