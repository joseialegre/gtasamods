--------------------------------- The Script maded by: Husnain--------------

//About Mod:
             So, Guys many peoples who cant play the game with fast style and smooth. But this 
Modification will allow you to Play game Smooth and Faster with 60 FPS. 

Remember:
          The Mod is not stealed with other. It been maded by author Husnain.




////////////////////////////////////// How to Install//////////////////////////////////////////

Copy the CLEO Folder on your GTA San Andreas Directory.

////////////////////////////////////// Requirement/////////////////////////////////////////////

This Mod Required CLEO 4 Version.


Thanks for Downloading. I hope yiu will ike it :)

dont Forget rate and feedback