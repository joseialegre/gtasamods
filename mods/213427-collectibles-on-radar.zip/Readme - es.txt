Collectibles on Radar
------------------------------------------------------------------------------------------------
Buen mod - Coleccionables en Radar para GTA San Andreas. Después de instalar este asi-plugin, su mapa y radar mostrarán objetos ocultos, graffiti, saltos y fotos. Los iconos son varias veces más pequeños, por lo que no interfieren con el juego. La modificación funciona incluso con mods que agregan o cambian coleccionables en el juego.

Administración:
"F12" - habilitar/deshabilitar el plugin.

Puede descargar Coleccionables en Radar para GTA San Andreas con instalación automática o manualmente desde los enlaces a continuación en esta página.

################################################################################################

AUTORES
------------------------------------------------------------------------------------------------
kong78

################################################################################################

INSTRUCCIONES DE INSTALACIÓN
------------------------------------------------------------------------------------------------
1. La copia de archivos

(!) No se olvide de hacer copias de la original de los archivos reemplazados a ser capaz de eliminar la modificación!

Copie todo el contenido de la carpeta "00 - Copy to game folder" a la carpeta donde está instalado el juego. Confirmar el reemplazo.

################################################################################################

Esta modificación ha sido descargado de www.gtaall.net

Permanent enlace a modification`s página: https://www.gtaall.net/gta-san-andreas/mods/213427-collectibles-on-radar.html

Compruebe nuestra sociales groups!
http://vk.com/gtaallcom
https://twitter.com/gtaallnet
http://www.facebook.com/gtaallcom
http://www.youtube.com/gtaallcom