Collectibles on Radar
------------------------------------------------------------------------------------------------
Gute Mod - Sammlerstücke auf Radar für GTA San Andreas. Nach der Installation dieses asi-Plugins zeigt Ihre Karte und Ihr Radar versteckte Objekte, Graffiti, Sprünge und Fotos an. Die Symbole sind um ein Vielfaches kleiner, so dass sie das Spiel nicht stören. Die Modifikation funktioniert sogar mit Mods, die Sammlerstücke im Spiel hinzufügen oder ändern.

Management:
"F12" - aktivieren / deaktivieren Sie das Plugin.

Sie können Collectibles auf Radar für GTA San Andreas mit automatischer Installation oder manuell über die Links unten auf dieser Seite herunterladen.

################################################################################################

AUTOREN
------------------------------------------------------------------------------------------------
kong78

################################################################################################

EINBAUANLEITUNG
------------------------------------------------------------------------------------------------
1. Kopieren von Dateien

(!) Vergessen Sie nicht, machen Kopien des Originals ersetzt Dateien in der Lage sein, um die Änderung zu entfernen!

Kopieren Sie den gesamten Inhalt des Ordners "00 - Copy to game folder" auf den Ordner, in dem das Spiel installiert ist. Bestätigen Sie den Ersatz.

################################################################################################

Diese Modifikation wurde von www.gtaall.eu heruntergeladen wurden
Permanent Link zu Seite modification`s: https://www.gtaall.eu/de/gta-san-andreas/mods/213427-collectibles-on-radar.html

Überprüfen unsere sozialen groups!
http://vk.com/gtaallcom
https://twitter.com/gtaallcom
http://www.facebook.com/gtaallcom
http://www.youtube.com/gtaallcom