Collectibles on Radar
------------------------------------------------------------------------------------------------
Good mod - Collectibles on Radar for GTA San Andreas. After installing this asi-plugin, your map and radar will display hidden objects, graffiti, jumps and photos. The icons are several times smaller, so they do not interfere with the game. The modification works even with mods that add or change collectibles in the game.

Management:
"F12" - enable/disable the plugin.

You can download Collectibles on Radar for GTA San Andreas with automatic installation or manually from the links below on this page.

################################################################################################

AUTHORS
------------------------------------------------------------------------------------------------
kong78

################################################################################################

INSTALLATION INSTRUCTIONS
------------------------------------------------------------------------------------------------
1. File copying

(!) Do not forget to make copies of the original replaced files to be able to remove the modification!

Copy all the contents of the folder "00 - Copy to game folder" to the folder where the game is installed. Confirm the replacement.

################################################################################################

This modification has been downloaded from www.gtaall.com

Permanent link to modification`s page: https://www.gtaall.com/gta-san-andreas/mods/213427-collectibles-on-radar.html

Check out our social groups!
http://vk.com/gtaallcom
https://twitter.com/gtaallcom
http://www.facebook.com/gtaallcom
http://www.youtube.com/gtaallcom