Collectibles on Radar
------------------------------------------------------------------------------------------------
Bom mod - Colecionáveis no radar para o GTA San Andreas. Depois de instalar este asi-plugin, seu mapa e radar exibirão objetos escondidos, grafites, saltos e fotos. Os ícones são várias vezes menores, por isso não interferem com o jogo. A modificação funciona mesmo com mods que adicionam ou alteram colecionáveis no jogo.

Gestão:
"F12" - ativar/desativar o plugin.

Você pode baixar Collectibles no radar para o GTA San Andreas com instalação automática ou manualmente a partir dos links abaixo nesta página.

################################################################################################

AUTORES
------------------------------------------------------------------------------------------------
kong78

################################################################################################

INSTRUÇÕES DE INSTALAÇÃO
------------------------------------------------------------------------------------------------
1. Cópia de arquivo

(!) Não se esqueça de fazer cópias do original arquivos substituídos para ser capaz de remover a modificação!

Copie todo o conteúdo da pasta "00 - Copy to game folder" para a pasta onde o jogo está instalado. Confirmar a substituição.

################################################################################################

Esta modificação foi baixado www.gtaall.com.br

Permanent link para modification`s página: https://www.gtaall.com.br/gta-san-andreas/mods/213427-collectibles-on-radar.html

Check a nossa sociais groups!
http://vk.com/gtaallcom
https://twitter.com/gtaallcombr
http://www.facebook.com/gtaallcom
http://www.youtube.com/gtaallcom