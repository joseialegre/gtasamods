Collectibles on Radar
------------------------------------------------------------------------------------------------
Bon mod - Objets de collection sur Radar pour GTA San Andreas. Après avoir installé ce plugin asi, votre carte et votre radar afficheront des objets cachés, des graffitis, des sauts et des photos. Les icônes sont plusieurs fois plus petites, elles n’interfèrent donc pas avec le jeu. La modification fonctionne même avec les mods qui ajoutent ou modifient des objets de collection dans le jeu.

Gestion:
« F12 » - activer / désactiver le plugin.

Vous pouvez télécharger Collectibles on Radar pour GTA San Andreas avec installation automatique ou manuellement à partir des liens ci-dessous sur cette page.

################################################################################################

AUTEURS
------------------------------------------------------------------------------------------------
kong78

################################################################################################

INSTRUCTIONS D'INSTALLATION
------------------------------------------------------------------------------------------------
1. La copie des fichiers

(!) Ne pas oublier de faire des copies de l'original remplacés fichiers pour être en mesure de retirer la modification!

Copiez tout le contenu du dossier "00 - Copy to game folder" dans le dossier où le jeu est installé. Confirmer le remplacement.

################################################################################################

Cette modification a été téléchargé à partir de www.gtaall.eu

Permanent lien vers modification`s page: https://www.gtaall.eu/fr/gta-san-andreas/mods/213427-collectibles-on-radar.html

Vérifier notre sociale groups!
http://vk.com/gtaallcom
https://twitter.com/gtaallcom
http://www.facebook.com/gtaallcom
http://www.youtube.com/gtaallcom