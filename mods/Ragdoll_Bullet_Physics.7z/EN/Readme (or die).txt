  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2021
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization in Notepad with monospaced font, as "Consolas".


------- Instructions:

Extract the "Ragdoll Bullet Physics" folder to your modloader folder.

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html



Notes:
  You can open the mod's .ini file and set it up as you like.
  There are .ini options inside "(settings)" folder.
  Doesn't applies to the player model (only if using some skin).


Commands:
  You can type "PUPPETER" (like a cheat) to enable a mode to "play" with peds.
  Enabled, while no weapons on hand, use the aim button to "get" a ped.
  Use the fire button to throw away the ped (hold to increase the power).
  Press L to apply levitation (no gravity).
 


Version: Final 20/03/17 (DD/MM/YY) + Mission fix + sociopart unofficial fix
--------------------

Author: madleg, Bullet Physics (http://bulletphysics.org)
Unofficial fix: sociopart, Crspy
Mission fix: Junior_Djjr


====   MixMods.com.br         ====
====   fb.com/FamiliaMixMods  ====

