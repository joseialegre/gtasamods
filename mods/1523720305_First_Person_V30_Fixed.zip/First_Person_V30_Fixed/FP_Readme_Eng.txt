=========== First-Person mod by BoPoH v3.0 ===========

(Sorry for my english...)
======================================================
=================== Description ======================

This modification will allow you to feel all abilities of GTA SA from the first person
Modification support most of animation mods, like parkour, etc.

======================================================
================= What's new (v3.0)===================

- FP now is a plugin, not CLEO-script
- Added compatibility with versions 1.1 and 3.0 (Steam) of GTA SA
- Now first-person mode replaces camera mode from car bumper
- Red mission markers are now available
- Now you can rotate camera 180 degrees in car in any side
- Fixed invisibility of peds, that are along you
- Fixed issue with shadows
- Added support of cutscenes and script cameras
- Fixed some poses in car
- Fixed zoom while you handle sniper rifle or photocamera
- Fixed resetting camera rotation when you exit car
- Added ability to look at the sides via Q and E
- Added ability to look back on foot
- Improved position of camera
- Fixed bug with invisible particles when you are in car
- Added ability to walk back and to sides
- Many small fixes
- Added settings menu where are next parameters:
	- Camera offset while on foot (saves separately for each skin)
	- Camera offset while in car (saves separately for each car model)
	- Field of view
	- Changing near plane
	- On/off player rotation with camera
	- On/off camera rotation at the sides while pressed Q or E

======================================================
==================== Install =========================

Unpack archive into folder with GTA San Andreas.
Modification supports 1.0, 1.1 and 3.0 game versions.

======================================================
=================== Controls =========================

Press button V several times to turn on first person mode. Press it again for turning off.
Press Alt+B to open settings menu. Press it again to turn off.

======================================================
==================== Autors ==========================

Autor of the modification - BoPoH (Voron295)
http://vk.com/voron295
http://vk.com/fs_online
http://gta-parkour.ru
http://youtube.com/voron295
voron295@gmail.com

======================================================
===================== Thanks =========================

- DK22Pac and DenSpb for helping in development
- Festo for the logo
- Alexey_Move for testing and making video-presentation of the modification