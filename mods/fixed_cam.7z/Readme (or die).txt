  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2019
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the folder "Fixed Cam" to your Modloader folder.

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html



 = Commands:
All commands are configurable in the .ini file.
F9     - Enable/Disable.
V      - Change camera.

Left Ctrl + B      - Open editor (while enabled). The commands will also be shown during the game.
Num4, Num6         - Move sideways.
Num2, Num8         - Move forward and backward.
Up/Down arrows     - Move up and down.
Space              - With the above commands, you will rotate the camera instead of moving.
Left/right arrows  - Tilt camera.

P          - Save settings.
BACKSPACE  - Cancel.

Type "RELOAD" inside the car with mod disabled to reload the .ini.
 


Version: v1.2
--------------------

Author: Pedr5
Thanks: Ruben Viera for suggestions.


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====

