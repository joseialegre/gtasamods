  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2020
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the folder "Faster Clothes Change" to your Modloader folder.

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html


Version: v1.0
--------------------

Author: Junior_Djjr


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====

